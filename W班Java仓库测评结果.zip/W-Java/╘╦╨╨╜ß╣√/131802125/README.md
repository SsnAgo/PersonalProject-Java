# 项目描述

[toc]

---

## 如何运行

>先从cmd窗口进入src文件夹，利用javac WordCount.java 再使用java WordCount input.txt output.txt来运行项目。

## 功能简介

>1. 对输入的input.txt的文本进行字符数统计。
>2. 对文本的单词数统计
>3. 对文本的有效行数进行统计
>4. 对统计频率最高的10个单词进行输出，如果同频率则按字典序小的在前。

## 作业连接

[软工实践寒假作业（2/2）](https://www.cnblogs.com/cj-whales/p/14488427.html)

## 博客连接

[我的博客](https://www.cnblogs.com/cj-whales/)

