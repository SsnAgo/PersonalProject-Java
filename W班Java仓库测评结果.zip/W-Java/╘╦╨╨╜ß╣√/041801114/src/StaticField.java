class StaticField {
    static final String CHARSET = "UTF-8";
    static final String LINE_SEPARATOR = "\n";
}
