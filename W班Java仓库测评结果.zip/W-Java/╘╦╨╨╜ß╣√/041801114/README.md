# 运行方式
```
java WordCount input.txt output.txt
```

# 功能简介
依据输入文件的内容，向输出文件输出以下内容：
1. 总字符数
2. 总单词数
3. 有效行数
4. 词频（取前10个）

# 作业链接
https://edu.cnblogs.com/campus/fzu/FZUSESPR21/homework/11672

# 博客链接
https://www.cnblogs.com/rrtwo/p/14427132.html