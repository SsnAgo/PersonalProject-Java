# 软工实践寒假作业（2/2）
### 功能简介
+ 本程序为文本统计软件
+ 输入文本文件，可得以下结果的输出文件

```javascript
characters: number
words: number
lines: number
word1: number
word2: number
...
```

### 运行方法
+ 在装有npm的环境下切换到WordCount所在目录输入命令行指令
```
node WordCount.js input.txt output.txt
```

### 作业链接
https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740

### 博客链接
https://www.cnblogs.com/garyClh029/p/14488023.html