|项目|WordCount词频统计|
|:----|:----|
|运行方法|1.javac -encoding UTF-8 WordCount.java 2.java WordCountinput.txt output.txt|
|功能简介|1.统计文件的字符数2.统计文件的单词数3.统计文件的有效行数4.统计文件中出现频率最高的10个单词|
|作业链接|[作业链接](https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740)|
|博客链接|[博客链接](https://www.cnblogs.com/suz10720/)|