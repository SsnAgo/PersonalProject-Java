# 项目介绍

------

## 使用方法
javac -encoding utf-8 WordCount.java
javac -encoding utf-8 FileTool.java
javac -encoding utf-8 ComputeTool.java
java WordCount input.txt output.txt


## 功能简介

通过在命令行输入输入输出文件的绝对路径后，可以实现：

1.统计字符数
2.统计单词数
3.统计最多的10个单词及其词频

## 作业链接

[寒假作业2/2](https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740)



## 博客链接 

[软工实践寒假作业2/2](https://www.cnblogs.com/aaagx/p/14484005.html)

