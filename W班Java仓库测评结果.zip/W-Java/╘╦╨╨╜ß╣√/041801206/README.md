传入参数如：input.txt output.txt

功能：统计一个txt文件的字符数，行数，单词数，并输出数量前十的单词

作业链接：https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740

博客链接：https://www.cnblogs.com/6666-6666/p/14438156.html