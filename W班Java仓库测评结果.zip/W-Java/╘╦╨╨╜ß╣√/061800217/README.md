
# WordCount
---

## 运行
>java countwords.WordCount [输入文件的路径] [输出文件的路径]

## 功能简介
>统计文件的字符数、统计文件的单词总数、统计文件的有效行数、统计文件中各单词的出现次数.

## 作业链接
>[作业]（https://www.cnblogs.com/isRui/p/14483299.html）
## 博客链接
>[博客]（https://www.cnblogs.com/isRui）
