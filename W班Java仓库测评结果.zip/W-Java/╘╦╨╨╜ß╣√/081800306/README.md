# WordCount
## 程序运行
- npm install 安装依赖
- 在081800306文件夹内 运行， node src/index.js input.txt output.txt
- 上面的命令，input.txt和output.txt是与src同级的两个文本文件，一个是输入，一个是输出文件。
## 作业连接
[作业](https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740)
## 博客链接
[博客](https://www.cnblogs.com/Dusks/p/14479970.html)