## wordCount

- 本项目是福州大学软工实践2021W班寒假第二次作业的仓库，只供学习交流。

## 开始

1. 运行, 设置输入输出文件

```
node src/index.js input.txt output.txt
```
