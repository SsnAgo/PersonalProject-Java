### 如何运行

使用命令行输入以下代码运行：

```java
javac -encoding UTF-8 WordCount.java
java WordCount input.txt output.txt
```

### 功能简介

统计input.txt中字符数、单词总数、有效行数、单词的出现次数（出现频率前10）

将统计结果输出到output.txt

### 作业链接

https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740

### 博客链接

https://www.cnblogs.com/hanma/p/14464590.html

