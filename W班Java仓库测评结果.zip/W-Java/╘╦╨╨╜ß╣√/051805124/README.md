读入文件 ——> 完成四个功能（统计字符总数、单词总数、有效行数、单词频率） ——> 写入文件

首先读入文件，采用java的文件流读入文件内容
再把读取的内容分发给四个独立的函数来处理
（在获取字符总数的时候，进行对字符频率用哈希表进行保存）
把处理后返回的结果进行拼接，写入到输出文件中去

作业链接https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740

博客链接https://www.cnblogs.com/kirito0206/p/14469225.html