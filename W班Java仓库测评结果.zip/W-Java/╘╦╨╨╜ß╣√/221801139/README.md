# 命令行程序WordCount

## 运行
```
java WordCount input.txt output.txt
```

***

## 功能简介
    词频统计，文本切割，排序输出

***

## 作业链接
https://www.cnblogs.com/jialin2021/p/14482678.html
***

## 博客链接
https://www.cnblogs.com/jialin2021/
