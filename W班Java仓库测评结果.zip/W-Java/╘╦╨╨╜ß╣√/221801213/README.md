
>## README

- 项目：文本词频统计

- 功能：对一个文本的字符数、行数、单词数统计以及统计显示出现频率最高的10个单词

- 如何运行：通过在项目目录下命令行运行java WordCount input.txt output.txt，其中input为要统计的文本，output存放结果 

- [作业链接](https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740)

- [博客链接](https://www.cnblogs.com/guodd/p/14452526.html)
