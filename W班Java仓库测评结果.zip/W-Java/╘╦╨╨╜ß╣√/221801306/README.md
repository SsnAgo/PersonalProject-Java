前二十次左右的commit 还不够熟练，在Summary 中填的都是默认的Update .java ，在Description 中填的才是具体commit 修改的内容，后来才直接把修改的内容填在Summary 中，所以要查看我前二十次左右的commit 修改的内容，要点开Description 才能看到。

[作业连接](https://edu.cnblogs.com/campus/fzu/2021SpringSoftwareEngineeringPractice/homework/11740)

[博客连接](https://www.cnblogs.com/Elsa1226/p/14483383.html)