public class WordCount {
    static Control con = new Control();
    public static void main(String[] args){
        con.set(args[0],args[1]);
        con.run();
    }
}
