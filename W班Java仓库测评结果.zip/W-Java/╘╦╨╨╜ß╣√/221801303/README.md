## 统计文本数据
### 运行
通过cmd传入输入文件和输出文件的路径即可

### 功能
统计输入文件中的字符数、行数、单词总数及单词出现次数并将其输出

### 作业链接
[https://github.com/6586744/PersonalProject-Java](https://github.com/6586744/PersonalProject-Java)

### 博客链接
[https://www.cnblogs.com/sjr6586744/p/14485383.html](https://www.cnblogs.com/sjr6586744/p/14485383.html)